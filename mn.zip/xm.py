import subprocess

SITELIST = "z.txt"
SAFE_FILE = "safe.txt"
INFECTED_FILE = "infected.txt"

CHECK_COMMAND = "ps aux | grep xmrig | grep -v grep"

def check_server(url):
    try:
        result = subprocess.run(
            ["python3", "security.py", "-u", url, "-c", CHECK_COMMAND],
            capture_output=True,
            text=True,
            timeout=60
        )

        output = result.stdout.strip()

        if "xmrig" in output:
            return "infected"
        else:
            return "safe"

    except Exception as e:
        print(f"[ERROR] {url} -> {e}")
        return None


def main():
    with open(SITELIST, "r") as f:
        servers = [line.strip() for line in f if line.strip()]

    for server in servers:
        print(f"[+] Checking {server}...")
        status = check_server(server)

        if status == "safe":
            with open(SAFE_FILE, "a") as sf:
                sf.write(server + "\n")
            print(f"[SAFE] {server}")

        elif status == "infected":
            with open(INFECTED_FILE, "a") as inf:
                inf.write(server + "\n")
            print(f"[INFECTED] {server}")

        else:
            print(f"[SKIPPED] {server}")


if __name__ == "__main__":
    main()
